$(document).ready(function() {
	$(".comments-body").dotdotdot({
	});	
});