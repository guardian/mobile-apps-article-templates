$(document).ready(function() {
	$(".card-header, .card-body").dotdotdot({
	});	
});

/* Inserts */
function cardsInserter(html) {
	$(html).appendTo(".related-container");
};